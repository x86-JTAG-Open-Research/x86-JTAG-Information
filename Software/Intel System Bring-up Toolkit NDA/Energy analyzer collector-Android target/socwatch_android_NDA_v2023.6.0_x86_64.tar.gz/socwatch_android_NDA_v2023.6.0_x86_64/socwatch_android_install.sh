#!/bin/bash
# ##################################################################################
# Copyright 2014 Intel Corporation

# The source code contained or described herein and all documents related
# to the source code ("Material") are owned by Intel Corporation or its
# suppliers or licensors. Title to the Material remains with Intel Corporation
# or its suppliers and licensors. The Material contains trade secrets and
# proprietary and confidential information of Intel or its suppliers and
# licensors. The Material is protected by worldwide copyright and trade secret
# laws and treaty provisions. No part of the Material may be used, copied,
# reproduced, modified, published, uploaded, posted, transmitted, distributed,
# or disclosed in any way without Intel's prior express written permission.

# No license under any patent, copyright, trade secret or other intellectual
# property right is granted to or conferred upon you by disclosure or delivery
# of the Materials, either expressly, by implication, inducement, estoppel or
# otherwise. Any license under such intellectual property rights must be express
# and approved by Intel in writing.
# #################################################################################

#
# A rudimentary script to copy the driver
# and support files to the Android
# target data.

# Set adb device number
ADB="adb"
BASE_DIR="/data"
APP_DIR="/data/data/com.intel.socwatchapp" # CANNOT be changed!

install_app=0;

usage()
{
    echo "";
    echo "Usage: ./socwatch_android_install <options>";
    echo "Where options are:";
    echo "";
    echo "  -s [device name]: specify a device name e.g. \"Medfield1234\".";
    echo "      Use this option if you typically have more than one device connected.";
    echo "";
    echo "  -d [install dir name]: specify the install directory.";
    echo "           e.g. /data/data/socwatch -- the socwatch user files will then be installed at /data/data/socwatch.";
    echo "       Defaults to /data/socwatch.";
    echo "";
    echo "  -a: install the SoC Watch app. The app will be installed in $APP_DIR"
    echo "";
}

check_connected_device()
{
    target_dir_test=`$ADB shell ls 2>&1`;
    if [[ $target_dir_test == *"error"* ]] ; then
        echo
        echo Please pass connected device name with -s option.
        echo
                adb devices
        exit 255; # -1
        fi
}

check_target_dir()
{
    target_dir="$1";
    target_dir_test=`$ADB shell ls $target_dir 2>&1`;
    while [[ ! "$target_dir_test" == *"No such file or directory"* ]] ; do
        echo
        echo   File or directory $target_dir already exists on the device.
        read -p   "Do you want to replace it (Y/N)?" yn
        case $yn in
            [yY] ) $ADB shell rm -r $target_dir ;;
            [nN] ) echo   "Please specifiy different installation path."; exit 255;; # -1
            *    ) echo   "Please answer Y or N." ;; # -1
        esac
        target_dir_test=`$ADB shell ls $target_dir 2>&1`;
    done
}

check_target_app()
{
    target_pkg="com.intel.socwatchapp";
    target_pkg_test=`$ADB shell pm list packages $target_pkg`;
    while [[ ! $target_pkg_test == "" ]]; do
        echo
        echo   The SoC Watch app is already installed on the device.
        read -p   "Do you want to replace it (Y/N)?" yn
        case $yn in
            [yY] ) $ADB uninstall $target_pkg &> /dev/null;;
            [nN] ) echo   "Please uninstall the app first."; exit 255;; # -1
            *    ) echo   "Please answer Y or N." ;; # -1
        esac
        target_pkg_test=`$ADB shell pm list packages $target_pkg`;
    done
}

make_dir()
{
    dir_name=$1;
    echo "Told to create dir ${dir_name}";
    ${ADB} shell mkdir -p ${dir_name};
    retVal=$?;
    if [ $retVal -ne 0 ]; then
        echo "ERROR creating dir ${dir_name}";
        usage;
        exit 255; # -1
    fi
    return $retVal;
}

install_file()
{
    file_name=$1;
    echo "Installing ${file_name}";
    ${ADB} install -r ${file_name};
    retVal=$?;
    if [ $retVal -ne 0 ]; then
        echo "ERROR installing ${file_name}";
        exit 255; #-1
    fi
    return $retVal;
}

copy_file()
{
    file_name=$1; dir_name=$2;
    echo "Copying ${file_name} to ${dir_name}";
    ${ADB} push ${file_name} ${dir_name};
    retVal=$?;
    if [ $retVal -ne 0 ]; then
        echo "ERROR copying ${file_name}";
        exit 255; #-1
    fi
    return $retVal;
}

while [ $# -gt 0 ]; do
    case $1 in
        "-s") shift; dev_name=$1;;
        "-d") shift; dir_name=$1;;
        "-a") install_app=1;;
        *) usage; exit 255;;
    esac
    shift
done

if [ "Z$dev_name" != "Z" ]; then
    ADB="${ADB} -s ${dev_name} wait-for-device";
    check_connected_device
else
    no_devices=`adb devices | grep device | grep -v devices | wc -l`
    if [ ! "$no_devices" = "0" ]; then
        if [ $no_devices -gt 1 ]; then
            echo ""
            echo "More than one device found.  Please, specify only one with -s option."
            exit 255
        fi
    else
        echo "Waiting on unspecified device to connect"
    fi
    ADB="${ADB} wait-for-device";
fi

if [ "Z$dir_name" != "Z" ]; then
    TARGET_DIR=${dir_name};
else
    TARGET_DIR="${BASE_DIR}/socwatch"
fi

if [ $install_app -eq 1 ]; then
    # Check to see if package is already installed -- if so, offer to uninstall it first
    check_target_app
fi

DRIVER_DIR="${TARGET_DIR}/driver"

${ADB} root
# check target dir existence - exit if it alreday exists
check_target_dir $TARGET_DIR

echo "Using ADB_CMD = ${ADB}"
echo "Using TARGET_DIR = ${TARGET_DIR}"

hostos=$(uname -s)
if [ ${hostos%_*} = "MINGW64" ] || [  ${hostos%_*} = "MINGW32" ] || [ ${hostos%_*} = "CYGWIN" ] ; then
    tools/dos2unix.exe setup_socwatch_env.sh
    tools/dos2unix.exe configs/SOCWatchConfig.txt
    tools/dos2unix.exe output_configs/default_config.txt
    tools/dos2unix.exe prepare_socwatch_app.sh
fi

install_app()
{
    x=`${ADB} install SoCWatchApp.apk | grep "Failure"`
    #echo "X is $x";
    if [ "Z$x" != "Z" ]; then
        echo "Couldn't install app because!";
        exit 255; # -1
    fi
}

install_files()
{
    install_dir=$1;
    # Copying userspace files
    copy_file socwatch ${install_dir}
    copy_file setup_socwatch_env.sh ${install_dir}
    copy_file configs ${install_dir}/configs/
    copy_file output_configs ${install_dir}/output_configs/
    copy_file plugins ${install_dir}/plugins/
    for soc in valleyview cherryview anniedale tangier broxton; do
        if [[ -d ${soc}_soc ]]; then
            copy_file ${soc}_soc ${install_dir}/${soc}_soc/
        fi
    done

    copy_file libs ${install_dir}/libs/
    # P.S.: exec perms don't survive the "adb push" process on Windows: force set the perms for 'socwatch' here.
    echo "Changing file perms for \"socwatch\""
    ${ADB} shell chmod 755 ${install_dir}/socwatch
    ${ADB} shell chmod 755 ${install_dir}/libs/*
}

create_link()
{
    from=$1;
    to=$2;
    echo "Creating symlink from ${from} to ${to}";
    ${ADB} shell ln -s ${to} ${from} # ln -s TARGET SOURCE
}

# No matter what, we always install socwatch to the install dir
make_dir $TARGET_DIR
install_files $TARGET_DIR
if [ $install_app -eq 1 ]; then
    INSTALL_DIR=$APP_DIR/bin
    SCRIPTS_DIR=$APP_DIR/script
    install_app
    # Make sure we also install the insmod script
    copy_file prepare_socwatch_app.sh $TARGET_DIR
    # P.S.: exec perms don't survive the "adb push" process on Windows: force set the perms for the insmod script here
    echo "Changing file perms for \"prepare_socwatch_app.sh\""
    ${ADB} shell chmod 766 ${INSTALL_DIR}/prepare_socwatch_app.sh
    # Link the bin directory to the SWA installation folder
    create_link $INSTALL_DIR $TARGET_DIR
fi

# Tell users about the new driver load/unload script
if [ $install_app -eq 1 ]; then
    echo "You will need to execute:"
    echo ""
    echo "      adb shell sh $TARGET_DIR/prepare_socwatch_app.sh -d <path to socwatch drivers directory>"
    echo ""
    echo "This must be done before running the SoC Watch app after each device reboot."
fi
echo "All done."
exit 0
